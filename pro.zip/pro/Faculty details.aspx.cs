﻿using System;
using System.Data.SqlClient;
using MessageBox = System.Windows.Forms.MessageBox;
using MessageBoxButtons = System.Windows.Forms.MessageBoxButtons;
using MessageBoxIcon = System.Windows.Forms.MessageBoxIcon;
using System.Text;
using Xamarin.Forms;
using System.Web.UI.WebControls;
using System.Web.UI;

namespace pro
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        SqlCommand command;
        SqlCommand command1;
      
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            bool allFieldsFilled = true;

            foreach (Control control in form1.Controls)
            {
                if (control is TextBox)
                {
                    TextBox textBox = (TextBox)control;
                    if (string.IsNullOrEmpty(textBox.Text))
                    {
                        allFieldsFilled = false;
                        break;
                    }
                }
                else if (control is RadioButtonList radioButtonList)
                {
                    bool anyButton = false;
                    foreach(ListItem listItem in radioButtonList.Items)
                    {
                        if(listItem.Selected)
                        {
                            anyButton = true;
                            break;
                        }
                    }
                    if (!anyButton)
                    {
                        allFieldsFilled = false;
                        break;
                    }
                }
                else if (control is TextBox dateTextBox)
                {
                    if(string.IsNullOrEmpty(dateTextBox.Text))
                    {
                        allFieldsFilled = false;
                        break;
                    }
                    else if (!DateTime.TryParse(dateTextBox.Text, out _))
                    {
                        allFieldsFilled = false;
                        break;
                    }
                }
            }
            if (allFieldsFilled)
            {
                // Process the form data
                string connectionSttring = "Data Source=localhost;Initial Catalog=Faculty;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionSttring))
                {
                    string Fid = TextBox1.Text;
                    string Fname = TextBox2.Text;
                    string Lname = TextBox3.Text;
                    DateTime selectedDate = DateTime.Parse(id4.Value);
                    string Pno = TextBox4.Text;
                    string e_mail = TextBox5.Text;
                    DateTime JoiningDate = DateTime.Parse(id7.Value);
                    string Designation = TextBox6.Text;
                    string Dept_id = TextBox7.Text;
                    //string Dept_id = Request.Form["dropdown"];
                    string House_no = TextBox8.Text;
                    string street = TextBox9.Text;
                    string city = TextBox10.Text;
                    string state = TextBox11.Text;
                    string Zip = TextBox12.Text;
                    string selectGender = Request.Form["Gender"];
                    string query = "INSERT INTO Faculty_deatils(FACT_ID,FNAME,LNAME,GENDER,DATEOFBIRTH,PHONE_NO,E_MAIL,JOING_DATE,DESIGNATION,DEPT_ID) VALUES(@Fid,@Fname,@Lname,@Gender,@selectedDate,@Pno,@e_mail,@JoiningDate,@Designation,@Dept_id)";
                    string query1 = "INSERT INTO ADDRESS_(FACT_ID,HOUSE_NO,STREET,CITY,STATE_,ZIP) VALUES(@Fid,@House_No,@Street,@City,@State,@Zip)";
                    //string query3 = "INSERT INTO DEPARMENT(DEPT_ID) VALUES(@DEPT_ID)";
                    command = new SqlCommand(query, connection);

                    command.Parameters.AddWithValue("@Fid", Fid);
                    command.Parameters.AddWithValue("@Fname", Fname);
                    command.Parameters.AddWithValue("@lname", Lname);
                    command.Parameters.AddWithValue("@Gender", selectGender);
                    command.Parameters.AddWithValue("@selectedDate", selectedDate);
                    command.Parameters.AddWithValue("@Pno", Pno);
                    command.Parameters.AddWithValue("@e_mail", e_mail);
                    command.Parameters.AddWithValue("@JoiningDate", JoiningDate);
                    command.Parameters.AddWithValue("@Designation", Designation);
                    command.Parameters.AddWithValue("@Dept_id", Dept_id);

                    command1 = new SqlCommand(query1, connection);

                    command1.Parameters.AddWithValue("@Fid", Fid);
                    command1.Parameters.AddWithValue("@House_No", House_no);
                    command1.Parameters.AddWithValue("@Street", street);
                    command1.Parameters.AddWithValue("@City", city);
                    command1.Parameters.AddWithValue("@State", state);
                    command1.Parameters.AddWithValue("@Zip", Zip);
                    connection.Open();

                    int row1 = command.ExecuteNonQuery();
                    int row2 = command1.ExecuteNonQuery();

                    if (row1 > 0 && row2 > 0)
                    {
                        MessageBox.Show("Data Inserted Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Data not Inserted properly", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                    connection.Close();
                    Response.Redirect(Request.Url.AbsoluteUri);
                }

            }
            else
            {
                // Display an error message or code
                MessageBox.Show("Data not Inserted properly all the Filed should be Entered", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Response.Redirect(Request.Url.AbsoluteUri);
            }


            
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("https://localhost:44334/Main%20page");
            Server.Transfer("https://localhost:44334/Main%20page");
        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}