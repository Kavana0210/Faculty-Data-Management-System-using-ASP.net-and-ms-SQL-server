﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Windows.Forms;
using System.Web.UI.WebControls;

namespace pro
{
    public partial class WebForm10 : System.Web.UI.Page
    {
        SqlCommand command;
        SqlCommand command1;
        SqlCommand command2;
        SqlCommand command3;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string connectionSttring = "Data Source=localhost;Initial Catalog=Faculty;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionSttring))
            {
                string Fid = TextBox1.Text;


                string query = "SELECT DEGREE,Specialization,YEAR_OF_PASSING,INSTITUTE FROM FACULTY_QUALIFICATION WHERE FACT_ID=@Fid";
                string query1 = "SELECT  WORK_EXP,JOB_ROLE,START__DATE,END__DATE FROM WORK_EXP WHERE FACT_ID=@Fid";
                command = new SqlCommand(query, connection);
                command1 = new SqlCommand(query1, connection);

                command.Parameters.AddWithValue("@Fid", Fid);
                command1.Parameters.AddWithValue("@Fid", Fid);

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();


                if (reader.Read())
                {
                    TextBox2.Text = reader["Degree"].ToString();
                    TextBox3.Text = reader["Specialization"].ToString();
                    TextBox4.Text = reader["Year_of_passing"].ToString();
                    TextBox5.Text = reader["Institute"].ToString();
                    
                }
                reader.Close();
                SqlDataReader reader1 = command1.ExecuteReader();

                if (reader1.Read())
                {
                    TextBox6.Text = reader1["WORK_EXP"].ToString();
                    TextBox7.Text = reader1["Job_role"].ToString();
                    DateTime startDate= Convert.ToDateTime(reader1["Start__Date"]);
                    id4.Value = startDate.ToString("yyyy-MM-dd");
                    DateTime endDate = Convert.ToDateTime(reader1["End__date"]);
                    id7.Value = endDate.ToString("yyyy-MM-dd");

                }

                reader1.Close();
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string connectionSttring = "Data Source=localhost;Initial Catalog=Faculty;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionSttring))
            {
                string Fid = TextBox1.Text;
                string Degree = TextBox2.Text;
                string Spec = TextBox3.Text;
                string Year = TextBox4.Text;
                string Institute = TextBox5.Text;
                string Institute1 = TextBox6.Text;
                string Job = TextBox7.Text;
                DateTime startDate = DateTime.Parse(id4.Value);
                DateTime endDate = DateTime.Parse(id7.Value);

                connection.Open();

                if(imageFile.HasFile)
                {
                    string tempPath = Path.Combine(Server.MapPath("~/TempImages"), imageFile.FileName);
                    imageFile.SaveAs(tempPath);
                    byte[] imageBytes = File.ReadAllBytes(tempPath);

                    string query2 = "UPDATE FACULTY_QUALIFICATION SET DEGREE=@Degree,SPECIALIZATION=@Specialization,YEAR_OF_PASSING=@Year,INSTITUTE=@Institute,DOC=@Doc WHERE FACT_ID=@Fid";
                    command2 = new SqlCommand(query2, connection);

                    command2.Parameters.AddWithValue("@Fid", Fid);
                    command2.Parameters.AddWithValue("@Degree", Degree);
                    command2.Parameters.AddWithValue("@Specialization", Spec);
                    command2.Parameters.AddWithValue("@Year", Year);
                    command2.Parameters.AddWithValue("@Institute", Institute);
                    command2.Parameters.AddWithValue("@Doc", imageBytes);
                    int row1 = command2.ExecuteNonQuery();
                    

                    if (row1 > 0 )
                    {
                        MessageBox.Show("Data Updated Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Data not Updated properly", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else if(imageFile1.HasFile)
                {
                    string tempPath1 = Path.Combine(Server.MapPath("~/TempImages"), imageFile1.FileName);
                    imageFile1.SaveAs(tempPath1);
                    byte[] imageBytes1 = File.ReadAllBytes(tempPath1);

                    string query3 = "UPDATE WORK_EXP SET WORK_EXP=@Institute1,JOB_ROLE=@Job_role,START__DATE=@startDate,END__DATE=@endDate,DOC=@Doc WHERE FACT_ID=@Fid";
                    command3 = new SqlCommand(query3, connection);

                    command3.Parameters.AddWithValue("@Fid", Fid);
                    command3.Parameters.AddWithValue("@Institute1", Institute1);
                    command3.Parameters.AddWithValue("@Job_role", Job);
                    command3.Parameters.AddWithValue("@startDate", startDate);
                    command3.Parameters.AddWithValue("@endDate", endDate);
                    command3.Parameters.AddWithValue("@Doc", imageBytes1);
                    int row1 = command3.ExecuteNonQuery();

                    if (row1 > 0)
                    {
                        MessageBox.Show("Data Updated Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Data not Updated properly", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else if(imageFile.HasFile && imageFile1.HasFile)
                {
                    string tempPath = Path.Combine(Server.MapPath("~/TempImages"), imageFile.FileName);
                    imageFile.SaveAs(tempPath);
                    string tempPath1 = Path.Combine(Server.MapPath("~/TempImages"), imageFile1.FileName);
                    imageFile1.SaveAs(tempPath1);
                    byte[] imageBytes = File.ReadAllBytes(tempPath);
                    byte[] imageBytes1 = File.ReadAllBytes(tempPath1);

                    
                    string query2 = "UPDATE FACULTY_QUALIFICATION SET DEGREE=@Degree,SPECIALIZATION=@Specialization,YEAR_OF_PASSING=@Year,INSTITUTE=@Institute,DOC=@Doc WHERE FACT_ID=@Fid";
                    string query3 = "UPDATE WORK_EXP SET WORK_EXP=@Institute1,JOB_ROLE=@Job_role,START__DATE=@startDate,END__DATE=@endDate,DOC==@Doc WHERE FACT_ID=@Fid";
                    command2 = new SqlCommand(query2, connection);
                    command3 = new SqlCommand(query3, connection);

                    command2.Parameters.AddWithValue("@Fid", Fid);
                    command2.Parameters.AddWithValue("@Degree", Degree);
                    command2.Parameters.AddWithValue("@Specialization", Spec);
                    command2.Parameters.AddWithValue("@Year", Year);
                    command2.Parameters.AddWithValue("@Institute", Institute);
                    command2.Parameters.AddWithValue("@Doc", imageBytes);

                    

                    command3.Parameters.AddWithValue("@Fid", Fid);
                    command3.Parameters.AddWithValue("@Institute1", Institute1);
                    command3.Parameters.AddWithValue("@Job_role", Job);
                    command3.Parameters.AddWithValue("@startDate", startDate);
                    command3.Parameters.AddWithValue("@endDate", endDate);
                    command3.Parameters.AddWithValue("@Doc", imageBytes1);
                    int row1 = command2.ExecuteNonQuery();
                    int row2 = command3.ExecuteNonQuery();

                    if (row1 > 0 && row2 > 0)
                    {
                        MessageBox.Show("Data Updated Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Data not Updated properly", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    string query = "UPDATE FACULTY_QUALIFICATION SET DEGREE=@Degree,SPECIALIZATION=@Specialization,YEAR_OF_PASSING=@Year,INSTITUTE=@Institute WHERE FACT_ID=@Fid";
                    string query1 = "UPDATE WORK_EXP SET WORK_EXP=@Institute1,JOB_ROLE=@Job_role,START__DATE=@startDate,END__DATE=@endDate WHERE FACT_ID=@Fid";
                    command = new SqlCommand(query, connection);

                    command.Parameters.AddWithValue("@Fid", Fid);
                    command.Parameters.AddWithValue("@Degree", Degree);
                    command.Parameters.AddWithValue("@Specialization", Spec);
                    command.Parameters.AddWithValue("@Year", Year);
                    command.Parameters.AddWithValue("@Institute", Institute);

                    command1 = new SqlCommand(query1, connection);

                    command1.Parameters.AddWithValue("@Fid", Fid);
                    command1.Parameters.AddWithValue("@Institute1", Institute1);
                    command1.Parameters.AddWithValue("@Job_role", Job);
                    command1.Parameters.AddWithValue("@startDate", startDate);
                    command1.Parameters.AddWithValue("@endDate", endDate);
                    int row1 = command.ExecuteNonQuery();
                    int row2 = command1.ExecuteNonQuery();

                    if (row1 > 0 && row2 > 0)
                    {
                        MessageBox.Show("Data Updated Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Data not Updated properly", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                
                connection.Close();
                Response.Redirect(Request.Url.AbsoluteUri);
            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("https://localhost:44334/Main%20page");
            Server.Transfer("https://localhost:44334/Main%20page");
        }
    }
}