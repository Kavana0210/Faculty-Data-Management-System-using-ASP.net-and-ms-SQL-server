﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pro
{
    public partial class WebForm12 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("https://localhost:44334/Faculty%20Details");
            Server.Transfer("https://localhost:44334/Faculty%20Details");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("https://localhost:44334/View%20Faculty%20Details.aspx");
            Server.Transfer("https://localhost:44334/View%20Faculty%20Details.aspx");
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("https://localhost:44334/Faculty%20Qulification.aspx");
            Server.Transfer("https://localhost:44334/Faculty%20Qulification.aspx");
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.Redirect("https://localhost:44334/View%20Faculty%20Qualifiication.aspx");
            Server.Transfer("https://localhost:44334/View%20Faculty%20Qualifiication.aspx");
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            Response.Redirect("https://localhost:44334/Faculty%20achivements");
            Server.Transfer("https://localhost:44334/Faculty%20achivements");
        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            Response.Redirect("https://localhost:44334/View%20Faculty%20Achivements");
            Server.Transfer("https://localhost:44334/View%20Faculty%20Achivements");
        }

        protected void Button7_Click(object sender, EventArgs e)
        {
            Response.Redirect("https://localhost:44334/Update%20Faculty%20Details.aspx");
            Server.Transfer("https://localhost:44334/Update%20Faculty%20Details.aspx");
        }

        protected void Button8_Click(object sender, EventArgs e)
        {
            Response.Redirect("https://localhost:44334/Update%20Faculty%20Qulification");
            Server.Transfer("https://localhost:44334/Update%20Faculty%20Qulification");
        }

        protected void Button9_Click(object sender, EventArgs e)
        {
            Response.Redirect("https://localhost:44334/Update%20Faculty%20Achivements");
            Server.Transfer("https://localhost:44334/Update%20Faculty%20Achivements");
        }

        protected void Button10_Click(object sender, EventArgs e)
        {
            Response.Redirect("https://localhost:44334/Delete");
            Server.Transfer("https://localhost:44334/Delete");
        }

        protected void Button11_Click(object sender, EventArgs e)
        {
            Response.Redirect("https://localhost:44334/View%20AllFaculty%20Details");
            Server.Transfer("https://localhost:44334/View%20AllFaculty%20Details");
        }
    }
}