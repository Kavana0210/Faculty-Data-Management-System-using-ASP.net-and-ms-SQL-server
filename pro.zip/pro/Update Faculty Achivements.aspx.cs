﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.IO;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Xamarin.Forms;

namespace pro
{
    public partial class WebForm11 : System.Web.UI.Page
    {
        SqlCommand command;
        SqlCommand command1;
        SqlCommand command2;
        SqlCommand command3;
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string connectionSttring = "Data Source=localhost;Initial Catalog=Faculty;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionSttring))
            {
                string Fid = TextBox1.Text;


                string query = "SELECT AWARD_TITLE,ORGANIZATION,AWARDED_DATE,DOC FROM AWARDS WHERE FACT_ID=@Fid";
                string query1 = "SELECT  PAPER_ID,PAPER_TITLE,PUBLISHED_DATE,PAPER_TYPE,DOC FROM PAPERS WHERE FACT_ID=@Fid";
                command = new SqlCommand(query, connection);
                command1 = new SqlCommand(query1, connection);

                command.Parameters.AddWithValue("@Fid", Fid);
                command1.Parameters.AddWithValue("@Fid", Fid);

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();


                if (reader.Read())
                {
                    TextBox2.Text = reader["AWARD_Title"].ToString();
                    TextBox3.Text = reader["Organization"].ToString();
                    DateTime startDate = Convert.ToDateTime(reader["Awarded_date"]);
                    id4.Value = startDate.ToString("yyyy-MM-dd");
                    
                }
                reader.Close();
                SqlDataReader reader1 = command1.ExecuteReader();

                if (reader1.Read())
                {
                    TextBox4.Text = reader1["Paper_id"].ToString();
                    TextBox5.Text = reader1["PAPER_Title"].ToString();
                    TextBox6.Text = reader1["paper_type"].ToString();
                    DateTime endDate = Convert.ToDateTime(reader1["Published_date"]);
                    id5.Value = endDate.ToString("yyyy-MM-dd");
                    
                }

                reader1.Close();

            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string connectionSttring = "Data Source=localhost;Initial Catalog=Faculty;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionSttring))
            {
                string Fid = TextBox1.Text;
                string title = TextBox2.Text;
                string Organization = TextBox3.Text;
                DateTime DateAwarded = DateTime.Parse(id4.Value);
                string paper_id = TextBox4.Text;
                string P_title = TextBox5.Text;
                DateTime DatePublished = DateTime.Parse(id5.Value);
                string type = TextBox6.Text;
                


                connection.Open();

                if(id2.HasFile)
                {
                    string tempPath = Path.Combine(Server.MapPath("~/TempImages"), id2.FileName);
                    id2.SaveAs(tempPath);
                    byte[] imageBytes = File.ReadAllBytes(tempPath);

                    string query2 = "UPDATE AWARDS SET AWARD_TITLE=@Title,ORGANIZATION=@Organization,AWARDED_DATE=@date,Doc=@Doc WHERE FACT_ID=@Fid";
                    command2 = new SqlCommand(query2, connection);

                    command2.Parameters.AddWithValue("@Fid", Fid);
                    command2.Parameters.AddWithValue("@Title", title);
                    command2.Parameters.AddWithValue("@Organization", Organization);
                    command2.Parameters.AddWithValue("@date", DateAwarded);
                    command2.Parameters.AddWithValue("Doc", imageBytes);

                    int row1 = command2.ExecuteNonQuery();

                    if (row1 > 0)
                    {
                        MessageBox.Show("Data Updated Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Data not Updated properly", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else if(id1.HasFile)
                {
                    string tempPath1 = Path.Combine(Server.MapPath("~/TempImages"), id1.FileName);
                    id1.SaveAs(tempPath1);
                    byte[] imageBytes1 = File.ReadAllBytes(tempPath1);

                    string query3 = "UPDATE PAPERS SET PAPER_ID=@Paper_id,PAPER_TITLE=@ptitle,PUBLISHED_DATE=@datePub,PAPER_TYPE=@type,Doc=@Doc WHERE FACT_ID=@Fid";
                    command3 = new SqlCommand(query3, connection);

                    command3.Parameters.AddWithValue("@Fid", Fid);
                    command3.Parameters.AddWithValue("Paper_id", paper_id);
                    command3.Parameters.AddWithValue("@ptitle", P_title);
                    command3.Parameters.AddWithValue("@datePub", DatePublished);
                    command3.Parameters.AddWithValue("@type", type);
                    command3.Parameters.AddWithValue("@Doc", imageBytes1);

                    int row1 = command3.ExecuteNonQuery();

                    if (row1 > 0)
                    {
                        MessageBox.Show("Data Updated Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Data not Updated properly", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else if(id1.HasFile && id2.HasFile)
                {
                    string tempPath = Path.Combine(Server.MapPath("~/TempImages"), id2.FileName);
                    id2.SaveAs(tempPath);
                    string tempPath1 = Path.Combine(Server.MapPath("~/TempImages"), id1.FileName);
                    id1.SaveAs(tempPath1);
                    byte[] imageBytes = File.ReadAllBytes(tempPath);
                    byte[] imageBytes1 = File.ReadAllBytes(tempPath1);

                    string query2 = "UPDATE AWARDS SET AWARD_TITLE=@Title,ORGANIZATION=@Organization,AWARDED_DATE=@date,Doc=@Doc WHERE FACT_ID=@Fid";
                    string query3 = "UPDATE PAPERS SET PAPER_ID=@Paper_id,PAPER_TITLE=@ptitle,PUBLISHED_DATE=@datePub,PAPER_TYPE=@type,Doc=@Doc WHERE FACT_ID=@Fid";

                    command2 = new SqlCommand(query2, connection);
                    command3 = new SqlCommand(query3, connection);

                    command2.Parameters.AddWithValue("@Fid", Fid);
                    command2.Parameters.AddWithValue("@Title", title);
                    command2.Parameters.AddWithValue("@Organization", Organization);
                    command2.Parameters.AddWithValue("@date", DateAwarded);
                    command2.Parameters.AddWithValue("Doc", imageBytes);


                    command3.Parameters.AddWithValue("@Fid", Fid);
                    command3.Parameters.AddWithValue("Paper_id", paper_id);
                    command3.Parameters.AddWithValue("@ptitle", P_title);
                    command3.Parameters.AddWithValue("@datePub", DatePublished);
                    command3.Parameters.AddWithValue("@type", type);
                    command3.Parameters.AddWithValue("@Doc", imageBytes1);

                    int row1 = command2.ExecuteNonQuery();
                    int row2 = command3.ExecuteNonQuery();

                    if (row1 > 0 && row2 > 0)
                    {
                        MessageBox.Show("Data Updated Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Data not Updated properly", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    string query = "UPDATE AWARDS SET AWARD_TITLE=@Title,ORGANIZATION=@Organization,AWARDED_DATE=@date WHERE FACT_ID=@Fid";
                    string query1 = "UPDATE PAPERS SET PAPER_ID=@Paper_id,PAPER_TITLE=@ptitle,PUBLISHED_DATE=@datePub,PAPER_TYPE=@type WHERE FACT_ID=@Fid";


                    command = new SqlCommand(query, connection);
                    command1 = new SqlCommand(query1, connection);



                    command.Parameters.AddWithValue("@Fid", Fid);
                    command.Parameters.AddWithValue("@Title", title);
                    command.Parameters.AddWithValue("@Organization", Organization);
                    command.Parameters.AddWithValue("@date", DateAwarded);


                    command1.Parameters.AddWithValue("@Fid", Fid);
                    command1.Parameters.AddWithValue("Paper_id", paper_id);
                    command1.Parameters.AddWithValue("@ptitle", P_title);
                    command1.Parameters.AddWithValue("@datePub", DatePublished);
                    command1.Parameters.AddWithValue("@type", type);
                    int row1 = command.ExecuteNonQuery();
                    int row2 = command1.ExecuteNonQuery();

                    if (row1 > 0 && row2 > 0)
                    {
                        MessageBox.Show("Data Updated Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Data not Updated properly", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }

                connection.Close();
                Response.Redirect(Request.Url.AbsoluteUri);
            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("https://localhost:44334/Main%20page");
            Server.Transfer("https://localhost:44334/Main%20page");
        }
    }
}
  