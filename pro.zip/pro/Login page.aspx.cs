﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Web.Services.Description;
using System.Web.UI;
using System.Windows.Forms;
using System.Data.SqlClient; 

using System.Web.UI.WebControls;

namespace pro
{
    public partial class WebForm13 : System.Web.UI.Page
    {
        public object MessageBox { get; private set; }
        public object loginErrorLiteral { get; private set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            if(IsPostBack)
            {
                string usernsme = TextBox1.Text;
                string password = TextBox2.Text;
                if(IsValidUser(usernsme,password))
                {
                    Response.Redirect("https://localhost:44334/Main%20page");
                }
                else
                {
                    Literal1.Visible = true;
                    Literal1.Text = "Invalid UserName or Password";
                }

            }
        }
        private bool IsValidUser(string username,string password)
        {
            return username == "Aiml05" && password == "Admin@123";
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if(IsValid)
            {

            }
        }
    }
}