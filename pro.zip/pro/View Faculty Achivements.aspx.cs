﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Xamarin.Forms;
using System.Windows.Forms;

namespace pro
{
    public partial class WebForm7 : System.Web.UI.Page
    {
        SqlCommand command;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            
            string connectionSttring = "Data Source=localhost;Initial Catalog=Faculty;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionSttring))
            {
                string Fid = TextBox1.Text;

                string query = "SELECT P.FACT_ID,PAPER_ID,P.PAPER_TITLE,PUBLISHED_DATE,PAPER_TYPE,A.AWARD_TITLE,ORGANIZATION,AWARDED_DATE FROM AWARDS A,PAPERS P WHERE P.FACT_ID=A.FACT_ID AND P.FACT_ID=@Fid";

                command = new SqlCommand(query, connection);

                Literal1.Visible = true;
                Literal1.Text = "Faculty Achivements";
                

                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable data = new DataTable();
                adapter.SelectCommand.Parameters.AddWithValue("@Fid", Fid);
                adapter.Fill(data);

                if (data.Rows.Count > 0)
                {
                    GridView1.DataSource = data;
                    GridView1.DataBind();
                }

            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("https://localhost:44334/Main%20page");
            Server.Transfer("https://localhost:44334/Main%20page");
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string facultyId = TextBox1.Text;

            if (!string.IsNullOrEmpty(facultyId))
            {
                // Replace with your connection string
                string connectionString = "Data Source=localhost;Initial Catalog=Faculty;Integrated Security=True";

                // Query the database to retrieve image data for the entered faculty ID
                byte[] facultyImageData = RetrieveFacultyImageDataFromDatabase(connectionString, facultyId);

                if (facultyImageData != null)
                {
                    string base64Image = Convert.ToBase64String(facultyImageData);
                    Image1.ImageUrl = "data:image/jpeg;base64," + base64Image;
                }
                else
                {
                    // Handle case where faculty image data is not found
                    Image1.ImageUrl = "";
                }
            }
        }
        private byte[] RetrieveFacultyImageDataFromDatabase(string connectionString, string facultyId)
        {
            byte[] imageData = null;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Replace with your actual query to retrieve image data based on faculty ID
                string query = "SELECT DOC FROM PAPERS WHERE FACT_ID = @FacultyId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@FacultyId", facultyId);

                connection.Open();
                imageData = (byte[])command.ExecuteScalar();
            }
            return imageData;
        }
    }
}