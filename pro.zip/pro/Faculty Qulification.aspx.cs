﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
//using System.IO;
using Path = System.IO.Path;
using File = System.IO.File;
using System.Linq;
using System.Web;
//using System.Windows.Forms;
using MessageBox = System.Windows.Forms.MessageBox;
using MessageBoxButtons = System.Windows.Forms.MessageBoxButtons;
using MessageBoxIcon = System.Windows.Forms.MessageBoxIcon;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pro
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        SqlCommand command;
        SqlCommand command1;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            bool allFieldsFilled = true;

            foreach (Control control in form1.Controls)
            {
                if (control is TextBox)
                {
                    TextBox textBox = (TextBox)control;
                    if (string.IsNullOrEmpty(textBox.Text))
                    {
                        allFieldsFilled = false;
                        break;
                    }
                }
                else if (control is TextBox dateTextBox)
                {
                    if (string.IsNullOrEmpty(dateTextBox.Text))
                    {
                        allFieldsFilled = false;
                        break;
                    }
                    else if (!DateTime.TryParse(dateTextBox.Text, out _))
                    {
                        allFieldsFilled = false;
                        break;
                    }
                }
            }
            if (allFieldsFilled)
            {
                // Process the form data
                string connectionSttring = "Data Source=localhost;Initial Catalog=Faculty;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionSttring))
                {
                    string Fid = TextBox1.Text;
                    string Degree = TextBox2.Text;
                    string Spec = TextBox3.Text;
                    string Year = TextBox4.Text;
                    string Institute = TextBox5.Text;
                    string Institute1 = TextBox6.Text;
                    string Job = TextBox7.Text;
                    DateTime startDate = DateTime.Parse(id4.Value);
                    DateTime endDate = DateTime.Parse(id5.Value);
                    string tempPath = Path.Combine(Server.MapPath("~/TempImages"), imageFile.FileName);
                    imageFile.SaveAs(tempPath);
                    //string tempPath1 = Path.Combine(Server.MapPath("~/TempImages"), imageFile1.FileName);
                    //imageFile1.SaveAs(tempPath1);
                    byte[] imageBytes = File.ReadAllBytes(tempPath);
                    //byte[] imageBytes1 = File.ReadAllBytes(tempPath1);

                    string query = "INSERT INTO FACULTY_QUALIFICATION(FACT_ID,DEGREE,SPECIALIZATION,YEAR_OF_PASSING,INSTITUTE,DOC) VALUES(@Fid,@Degree,@Specialization,@Year_of_passing,@Institute,@Doc)";
                    string query1 = "INSERT INTO WORK_EXP(FACT_ID,WORK_EXP,JOB_ROLE,START__DATE,END__DATE) VALUES(@Fid,@Institute1,@Job,@start__date,@end__date)";
                    command = new SqlCommand(query, connection);

                    command.Parameters.AddWithValue("@Fid", Fid);
                    command.Parameters.AddWithValue("@Degree", Degree);
                    command.Parameters.AddWithValue("@Specialization", Spec);
                    command.Parameters.AddWithValue("@Year_of_passing", Year);
                    command.Parameters.AddWithValue("@Institute", Institute);
                    command.Parameters.AddWithValue("@Doc", imageBytes);

                    command1 = new SqlCommand(query1, connection);

                    command1.Parameters.AddWithValue("@Fid", Fid);
                    command1.Parameters.AddWithValue("@Institute1", Institute1);
                    command1.Parameters.AddWithValue("@Job", Job);
                    command1.Parameters.AddWithValue("@start__date", startDate);
                    command1.Parameters.AddWithValue("@end__date", endDate);
                    //command1.Parameters.AddWithValue("@Doc", imageBytes1);

                    connection.Open();
                    int row1 = command.ExecuteNonQuery();
                    int row2 = command1.ExecuteNonQuery();

                    if (row1 > 0 && row2 > 0)
                    {
                        MessageBox.Show("Data Inserted Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Data not Inserted properly", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                    File.Delete(tempPath);
                    //File.Delete(tempPath1);
                    connection.Close();
                    Response.Redirect(Request.Url.AbsoluteUri);
                }
            }
            else
            {
                // Display an error message or code
                MessageBox.Show("Data not Inserted properly all the Filed should be Entered", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Response.Redirect(Request.Url.AbsoluteUri);
            }




            
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("https://localhost:44334/Main%20page");
            Server.Transfer("https://localhost:44334/Main%20page");
        }
    }
}