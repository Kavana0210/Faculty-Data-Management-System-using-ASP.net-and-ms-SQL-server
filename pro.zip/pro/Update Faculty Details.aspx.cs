﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace pro
{
    public partial class WebForm9 : System.Web.UI.Page
    {
        SqlCommand command;
        SqlCommand command1;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string connectionSttring = "Data Source=localhost;Initial Catalog=Faculty;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionSttring))
            {
                string Fid = TextBox1.Text;

                string query = "SELECT FNAME,LNAME,PHONE_NO,DATEOFBIRTH,E_MAIL,JOING_DATE,DESIGNATION,DEPT_ID FROM FACULTY_DEATILS WHERE FACT_ID=@Fid";
                string query1 = "SELECT HOUSE_NO,STREET,CITY,STATE_,ZIP FROM ADDRESS_ WHERE FACT_ID=@Fid";
                string query2 = "SELECT GENDER FROM FACULTY_DEATILS WHERE FACT_ID=@Fid";
                command = new SqlCommand(query, connection);
                command1 = new SqlCommand(query1, connection);
                SqlCommand command2 = new SqlCommand(query2, connection);

                command.Parameters.AddWithValue("@Fid", Fid);
                command1.Parameters.AddWithValue("@Fid", Fid);
                command2.Parameters.AddWithValue("@Fid", Fid);

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                

                if(reader.Read())
                {
                    TextBox2.Text = reader["Fname"].ToString();
                    TextBox3.Text = reader["Lname"].ToString();
                    TextBox4.Text = reader["Phone_no"].ToString();
                    DateTime dateofBirth = Convert.ToDateTime(reader["DATEOFBIRTH"]);
                    id4.Value = dateofBirth.ToString("yyyy-MM-dd");
                    TextBox5.Text = reader["E_mail"].ToString();
                    DateTime JoiningDate = Convert.ToDateTime(reader["Joing_date"]);
                    id7.Value = JoiningDate.ToString("yyyy-MM-dd");
                    TextBox6.Text = reader["Designation"].ToString();
                    TextBox7.Text = reader["Dept_id"].ToString();
                }
                reader.Close();
                SqlDataReader reader1 = command1.ExecuteReader();

                if (reader1.Read())
                {
                    TextBox8.Text = reader1["House_no"].ToString();
                    TextBox9.Text = reader1["Street"].ToString();
                    TextBox10.Text = reader1["City"].ToString();
                    TextBox11.Text = reader1["State_"].ToString();
                    TextBox12.Text = reader1["Zip"].ToString();
                }
                reader1.Close();
                object select = command2.ExecuteScalar();


                if(select!=null)
                {
                    if(select.ToString()=="Male")
                    {
                        inlineRadio1.Checked = true;
                    }
                    else if(select.ToString()=="Female")
                    {
                        inlineRadio2.Checked = true;
                    }
                    else if(select.ToString()=="Others")
                    {
                        inlineRadio3.Checked = true;
                    }
                }
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string connectionSttring = "Data Source=localhost;Initial Catalog=Faculty;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionSttring))
            {
                string Fid = TextBox1.Text;
                string Fname = TextBox2.Text;
                string Lname = TextBox3.Text;
                DateTime selectedDate = DateTime.Parse(id4.Value);
                string Pno = TextBox4.Text;
                string e_mail = TextBox5.Text;
                DateTime JoiningDate = DateTime.Parse(id7.Value);
                string Designation = TextBox6.Text;
                string Dept_id = TextBox7.Text;
                string House_no = TextBox8.Text;
                string street = TextBox9.Text;
                string city = TextBox10.Text;
                string state = TextBox11.Text;
                string Zip = TextBox12.Text;
                string selectGender = Request.Form["Gender"];
                string query = "UPDATE FACULTY_DEATILS SET FNAME=@Fname,LNAME=@Lname,GENDER=@Gender,DATEOFBIRTH=@Dob,PHONE_NO=@Pno,E_MAIL=@mail,JOING_DATE=@Jdate,DESIGNATION=@Designation,DEPT_ID=@D_id WHERE FACT_ID=@Fid";
                string query1 = "UPDATE ADDRESS_ SET HOUSE_NO=@House_no,STREET=@Street,CITY=@City,STATE_=@State,ZIP=@Zip WHERE FACT_ID=@Fid";
                command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@Fid", Fid);
                command.Parameters.AddWithValue("@Fname", Fname);
                command.Parameters.AddWithValue("@Lname", Lname);
                command.Parameters.AddWithValue("@Gender", selectGender);
                command.Parameters.AddWithValue("@Dob", selectedDate);
                command.Parameters.AddWithValue("@Pno", Pno);
                command.Parameters.AddWithValue("@mail", e_mail);
                command.Parameters.AddWithValue("@Jdate", JoiningDate);
                command.Parameters.AddWithValue("@Designation", Designation);
                command.Parameters.AddWithValue("@D_id", Dept_id);

                command1 = new SqlCommand(query1, connection);

                command1.Parameters.AddWithValue("@Fid", Fid);
                command1.Parameters.AddWithValue("@House_No", House_no);
                command1.Parameters.AddWithValue("@Street", street);
                command1.Parameters.AddWithValue("@City", city);
                command1.Parameters.AddWithValue("@State", state);
                command1.Parameters.AddWithValue("@Zip", Zip);
                connection.Open();
                int row1 = command.ExecuteNonQuery();
                int row2 = command1.ExecuteNonQuery();

                if (row1 > 0 && row2 > 0)
                {
                    MessageBox.Show("Data Updated Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Data not Updated properly", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                connection.Close();
                Response.Redirect(Request.Url.AbsoluteUri);
            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("https://localhost:44334/Main%20page");
            Server.Transfer("https://localhost:44334/Main%20page");
        }
    }
}